# IMPORTANT: Execute this file only when you want sample 10 questions (if you are lazy of adding them manually or for testing purposes)
sample_questions = {
    "DSA": [
        {
            "question": "What data structure uses LIFO (Last-In, First-Out)?",
            "options": ["Queue", "Array", "Stack", "Linked List"],
            "answer": "Stack",
        },
        {
            "question": "Which algorithm technique is used in binary search?",
            "options": [
                "Divide and Conquer",
                "Dynamic Programming",
                "Greedy",
                "Backtracking",
            ],
            "answer": "Divide and Conquer",
        },
        {
            "question": "What is the time complexity of inserting an element in an array at the end?",
            "options": ["O(1)", "O(n)", "O(log n)", "O(n log n)"],
            "answer": "O(1)",
        },
        {
            "question": "Which data structure is used for BFS traversal?",
            "options": ["Stack", "Queue", "Heap", "Set"],
            "answer": "Queue",
        },
        {
            "question": "Which sorting algorithm has the best average case time complexity?",
            "options": [
                "Bubble Sort",
                "Merge Sort",
                "Selection Sort",
                "Insertion Sort",
            ],
            "answer": "Merge Sort",
        },
        {
            "question": "What is the worst-case time complexity of QuickSort?",
            "options": ["O(n)", "O(log n)", "O(n^2)", "O(n log n)"],
            "answer": "O(n^2)",
        },
        {
            "question": "Which data structure is used in Dijkstra's algorithm?",
            "options": ["Stack", "Queue", "Priority Queue", "Hash Map"],
            "answer": "Priority Queue",
        },
        {
            "question": "Which of these is a greedy algorithm?",
            "options": [
                "Dijkstra's Algorithm",
                "Dynamic Programming",
                "Binary Search",
                "Merge Sort",
            ],
            "answer": "Dijkstra's Algorithm",
        },
        {
            "question": "What traversal technique is used for recursive DFS?",
            "options": [
                "Breadth-First Search",
                "Depth-First Search",
                "Level Order Traversal",
                "In-order Traversal",
            ],
            "answer": "Depth-First Search",
        },
        {
            "question": "Hashing provides which of the following?",
            "options": [
                "O(1) average search",
                "Sorted data",
                "Tree structure",
                "Linked list",
            ],
            "answer": "O(1) average search",
        },
    ],
    "Python": [
        {
            "question": "What is the output of 3 * 1 ** 3?",
            "options": ["3", "1", "9", "None"],
            "answer": "3",
        },
        {
            "question": "In Python, which keyword is used to define a function?",
            "options": ["func", "define", "def", "func()"],
            "answer": "def",
        },
        {
            "question": "Which data type is immutable?",
            "options": ["list", "set", "tuple", "dict"],
            "answer": "tuple",
        },
        {
            "question": "How do you insert an element into a set?",
            "options": [
                "set.add()",
                "set.insert()",
                "set.append()",
                "set.insert_element()",
            ],
            "answer": "set.add()",
        },
        {
            "question": "What keyword is used for class inheritance?",
            "options": ["extends", "inherits", "super", "class"],
            "answer": "super",
        },
        {
            "question": "Which method is used to add an item to a list?",
            "options": ["add()", "append()", "insert()", "push()"],
            "answer": "append()",
        },
        {
            "question": "How is a lambda function defined?",
            "options": [
                "lambda args: expression",
                "def lambda: expression",
                "func lambda: expression",
                "lambda: args",
            ],
            "answer": "lambda args: expression",
        },
        {
            "question": "What does the 'pass' statement do?",
            "options": [
                "Does nothing",
                "Ends loop",
                "Returns value",
                "Raises exception",
            ],
            "answer": "Does nothing",
        },
        {
            "question": "Which operator is used for matrix transpose?",
            "options": [".T", "transpose()", "T", "transpose"],
            "answer": ".T",
        },
        {
            "question": "Which module is used for regular expressions?",
            "options": ["re", "regex", "pattern", "repattern"],
            "answer": "re",
        },
    ],
    "DBMS": [
        {
            "question": "What does SQL stand for?",
            "options": [
                "Structured Query Language",
                "Strong Question Language",
                "Structured Question Language",
                "Simple Query Language",
            ],
            "answer": "Structured Query Language",
        },
        {
            "question": "Which command is used to remove a table?",
            "options": ["DROP TABLE", "REMOVE TABLE", "DELETE TABLE", "TRUNCATE"],
            "answer": "DROP TABLE",
        },
        {
            "question": "What is the primary key used for?",
            "options": [
                "Unique identification of records",
                "Foreign key reference",
                "Sorting records",
                "Indexing",
            ],
            "answer": "Unique identification of records",
        },
        {
            "question": "Which normalization form is based on eliminating transitive dependency?",
            "options": [
                "First Normal Form",
                "Second Normal Form",
                "Third Normal Form",
                "Boyce-Codd Normal Form",
            ],
            "answer": "Third Normal Form",
        },
        {
            "question": "What does an ER diagram depict?",
            "options": [
                "Entity Relationship",
                "Entity and Relationship",
                "Entity Records",
                "Entity Relationship Diagram",
            ],
            "answer": "Entity Relationship",
        },
        {
            "question": "Which join type returns all rows from the left table and matching rows from the right?",
            "options": [
                "Inner Join",
                "Left Outer Join",
                "Right Outer Join",
                "Full Outer Join",
            ],
            "answer": "Left Outer Join",
        },
        {
            "question": "What is a composite key?",
            "options": [
                "Key made of multiple columns",
                "Unique key",
                "Primary key",
                "Foreign key",
            ],
            "answer": "Key made of multiple columns",
        },
        {
            "question": "Which command is used to change data in a table?",
            "options": ["UPDATE", "MODIFY", "CHANGE", "SET"],
            "answer": "UPDATE",
        },
        {
            "question": "In which normal form is a relation free of multivalued dependencies?",
            "options": ["First NF", "Second NF", "Third NF", "Fourth NF"],
            "answer": "Fourth NF",
        },
        {
            "question": "What does SQL injection mean?",
            "options": [
                "Security attack",
                "Coding error",
                "Data corruption",
                "Query optimization",
            ],
            "answer": "Security attack",
        },
    ],
}


# Optionally add a function to write this data to Quiz.txt


def save_sample_questions(filename="Quiz.txt"):
    with open(filename, "w") as f:
        f.write(str(sample_questions))


if __name__ == "__main__":
    save_sample_questions()
